export type TransactionType = 'income' | 'expense'

// The category used for the expense transaction logged whenever money moves into a Goal or
// Important Date (payday auto-allocation, or the "add funds" quick-action on either card) — see
// allocateToGoal/allocateToImportantDate in App.tsx. Shared so every place that needs to
// recognize "this expense is actually a savings transfer, not real spending" (Dashboard's savings
// card, the insights engine) agrees on the exact string.
export const SAVINGS_CATEGORY = 'Savings'

export interface Transaction {
  id: string
  date: string // ISO date
  amount: number // always positive; sign determined by type
  type: TransactionType
  category: string
  note: string
}

export type CategoryIconKey =
  | 'food'
  | 'groceries'
  | 'coffee'
  | 'transport'
  | 'publicTransport'
  | 'bike'
  | 'fuel'
  | 'home'
  | 'housing'
  | 'shopping'
  | 'clothing'
  | 'travel'
  | 'entertainment'
  | 'music'
  | 'streaming'
  | 'games'
  | 'bills'
  | 'utilities'
  | 'water'
  | 'internet'
  | 'phone'
  | 'health'
  | 'medical'
  | 'pharmacy'
  | 'fitness'
  | 'beauty'
  | 'income'
  | 'savings'
  | 'bank'
  | 'creditCard'
  | 'wallet'
  | 'work'
  | 'education'
  | 'books'
  | 'gift'
  | 'charity'
  | 'tech'
  | 'maintenance'
  | 'hobby'
  | 'pets'
  | 'kids'
  | 'family'
  | 'insurance'
  | 'emergency'
  | 'outdoors'
  | 'parking'
  | 'other'

export interface CategoryDef {
  name: string
  icon: CategoryIconKey
}

export type BudgetPeriod = 'day' | 'week' | 'month' | 'year'

export interface CategoryBudget {
  category: string
  limit: number
  period: BudgetPeriod
  // When this budget was created — used only to tell whether a given completed period (e.g.
  // "last week") happened before or after this budget existed, so the period-review banner
  // (lib/budgetPeriods.ts) doesn't review a period this budget wasn't around to track.
  // migrate() backfills existing budgets with an old-enough timestamp so they're reviewed
  // right away — only a genuinely new budget skips its first not-yet-lived-through period.
  createdAt: string
}

export type GoalIcon =
  | 'flight'
  | 'clothes'
  | 'travel'
  | 'tech'
  | 'home'
  | 'gift'
  | 'car'
  | 'education'
  | 'health'
  | 'emergencyFund'
  | 'pet'
  | 'hobby'
  | 'phone'
  | 'music'
  | 'fitness'
  | 'kids'
  | 'charity'
  | 'business'
  | 'renovation'
  | 'debt'
  | 'savings'
  | 'insurance'
  | 'outdoors'
  | 'wedding'
  | 'furniture'
  | 'books'
  | 'games'
  | 'food'
  | 'family'
  | 'shopping'
  | 'bike'
  | 'other'

export interface Goal {
  id: string
  name: string
  targetAmount: number
  savedAmount: number
  targetDate: string // ISO date
  icon: GoalIcon
  createdAt: string
}

export interface Settings {
  currency: string
  monthlyIncome: number // baseline income; treated as the person's basic salary
  theme: ThemeKey
  salaryDay?: number // day of month (1-31) the basic salary is paid — powers the payday auto-savings prompt
  // Tracks which paydays have already been applied/dismissed this month, so the prompt
  // doesn't repeat. Keyed by 'primary' for the basic salary above, or an IncomeSource id
  // for an extra income source — each pays on its own day and gets its own reminder.
  handledPaydays?: Record<string, string> // key -> 'YYYY-MM'
  // Tracks which completed budget periods have already been reviewed (surplus moved somewhere,
  // overspend acknowledged, or just dismissed) — see lib/budgetPeriods.ts. Keyed by
  // `${category}::${period}` (the same composite identity BudgetsView already treats a budget
  // by), value is that budget's periodInstanceKey at last review, so the banner reappears
  // exactly once per newly-completed period and never repeats for one already handled.
  handledBudgetPeriods?: Record<string, string>
  // UI language. Optional on the type only so older saved states (before this field existed)
  // still satisfy it structurally — migrate() in storage.ts always backfills a real value
  // ('en') on load, so every other reader of Settings can treat it as always present.
  language?: Language
}

/** Supported UI languages — see src/lib/i18n/ for the dictionaries and translation hook. */
export type Language = 'en' | 'ru' | 'lv'

/** An extra source of income beyond the basic salary — a second job, freelance work, etc. —
 * with its own monthly amount and payday, for people with more than one income. */
export interface IncomeSource {
  id: string
  name: string
  amount: number
  payDay: number // day of month, 1-31
}

export type ThemeKey = 'light' | 'dark' | 'cyber' | 'red' | 'pinky' | 'caramel'

export interface Insight {
  id: string
  tone: 'positive' | 'warning' | 'info'
  title: string
  message: string
  createdAt: string
}

/** How long before the target date a reminder should fire. */
export type ReminderOffsetKey = '2_months' | '1_month' | '2_weeks' | '1_week' | '3_days' | '1_day' | 'on_day'

/** What kind of thing a reminder rule points at — a savings goal or an important date. */
export type ReminderTargetKind = 'goal' | 'importantDate'

/** One reminder schedule: an ordered set of "fire this many days before the date" checkpoints. */
export interface ReminderRule {
  targetKind: ReminderTargetKind
  targetId: string
  offsets: ReminderOffsetKey[]
}

export type ImportantDateCategory =
  | 'birthday'
  | 'anniversary'
  | 'holiday'
  | 'carMaintenance'
  | 'gift'
  | 'medical'
  | 'education'
  | 'travel'
  | 'homeMaintenance'
  | 'petCare'
  | 'family'
  | 'finance'
  | 'insurance'
  | 'subscription'
  | 'other'

export interface ImportantDate {
  id: string
  name: string
  date: string // ISO date. For a recurring date, the year is arbitrary — only month/day are used.
  category: ImportantDateCategory
  recurring: boolean // true = repeats every year (birthdays, holidays); false = one-off (an appointment)
  createdAt: string
  targetAmount?: number // optional — how much to set aside for this (a gift, a service bill...)
  savedAmount?: number
}

export interface AppState {
  transactions: Transaction[]
  budgets: CategoryBudget[]
  goals: Goal[]
  categories: CategoryDef[]
  importantDates: ImportantDate[]
  reminderRules: ReminderRule[]
  incomeSources: IncomeSource[]
  settings: Settings
  // Ids of insights/reminders already seen on the Notifications page — everything currently
  // showing there gets marked read the moment that page opens (see App.tsx).
  readNotificationIds: string[]
}

export const DEFAULT_CATEGORIES = [
  'Food',
  'Transport',
  'Rent',
  'Shopping',
  'Travel',
  'Entertainment',
  'Bills',
  'Health',
  'Other',
] as const

export const DEFAULT_CATEGORY_DEFS: CategoryDef[] = [
  { name: 'Food', icon: 'food' },
  { name: 'Transport', icon: 'transport' },
  { name: 'Rent', icon: 'home' },
  { name: 'Shopping', icon: 'shopping' },
  { name: 'Travel', icon: 'travel' },
  { name: 'Entertainment', icon: 'entertainment' },
  { name: 'Bills', icon: 'bills' },
  { name: 'Health', icon: 'health' },
  { name: 'Salary', icon: 'income' },
  { name: 'Freelance', icon: 'work' },
  { name: SAVINGS_CATEGORY, icon: 'savings' },
  { name: 'Other', icon: 'other' },
]

