import { useMemo, useState } from 'react'
import { Plus, TrendingUp, TrendingDown, PiggyBank, Wallet2, ArrowRight, CheckCircle2, AlertTriangle } from 'lucide-react'
import { AppState, Transaction, Insight, CategoryDef, SAVINGS_CATEGORY } from '../types'
import { formatMoney, periodRange, filterByRange, totals, settingsIncomeForPeriod, parseLocalDate } from '../lib/utils'
import { Card, ProgressBar, budgetTone } from './shared'
import { CategoryIconGlyph, iconForCategory, translateCategoryName } from '../lib/categoryIcons'
import AddTransactionModal from './AddTransactionModal'
import SalaryPromptBanner from './SalaryPromptBanner'
import BudgetPeriodBanner from './BudgetPeriodBanner'
import { duePaydaySources, planForMonth, startOfMonth, budgetDailyRate } from '../lib/planning'
import { BudgetPeriodReview, pendingBudgetPeriodReviews } from '../lib/budgetPeriods'
import { ViewKey } from '../App'
import { useI18n } from '../lib/i18n'

export default function Dashboard({
  state,
  insights,
  addTransaction,
  addCategory,
  setView,
  applyAutoAllocations,
  dismissSalaryPrompt,
  moveBudgetSurplusToGoal,
  moveBudgetSurplusToImportantDate,
  reduceBudgetLimitForOverspend,
  dismissBudgetPeriodReview,
}: {
  state: AppState
  insights: Insight[]
  addTransaction: (t: Omit<Transaction, 'id'>) => void
  addCategory: (def: CategoryDef) => void
  setView: (v: ViewKey) => void
  applyAutoAllocations: (excludeKeys?: string[]) => void
  dismissSalaryPrompt: () => void
  moveBudgetSurplusToGoal: (review: BudgetPeriodReview, goalId: string) => void
  moveBudgetSurplusToImportantDate: (review: BudgetPeriodReview, dateId: string) => void
  reduceBudgetLimitForOverspend: (review: BudgetPeriodReview) => void
  dismissBudgetPeriodReview: (review: BudgetPeriodReview) => void
}) {
  const { t, locale } = useI18n()
  const [showAdd, setShowAdd] = useState(false)
  const [period, setPeriod] = useState<'month' | 'year'>('month')

  const today0 = new Date()

  // Always-current-calendar-month figures, independent of the period toggle above — used
  // for the budget health card and the savings goal card, which are inherently monthly.
  const currentMonthRange = periodRange('month', today0)
  const currentMonthTx = filterByRange(state.transactions, currentMonthRange.from, currentMonthRange.to)

  // Figures for the stat row, which follow the "This Month" / "This Year" toggle. Uses the
  // same settingsIncomeForPeriod() helper Reports uses, so the two screens can't drift apart
  // on what "income" means again.
  const { from, to } = periodRange(period, today0)
  const periodTx = filterByRange(state.transactions, from, to)
  const periodLogged = totals(periodTx)
  const monthsInPeriod = period === 'month' ? 1 : today0.getMonth() + 1
  const income = settingsIncomeForPeriod(state.settings, state.incomeSources, period, today0) + periodLogged.income
  const expense = periodLogged.expense
  const balance = totals(state.transactions).net
  const periodLabel = period === 'month' ? t.periods.thisMonth : t.periods.thisYear

  // Budget health — EVERY budget counts here now, whatever its period. A day/week/year
  // budget is converted to a monthly-equivalent limit with the same budgetDailyRate() used
  // by planForMonth (Calendar, the payday banner, "In theory you can save" below), so a
  // yearly budget no longer disappears from this card just because it isn't a "month"
  // budget. "Spent" is actual spend this month per category — deduplicated by category, so a
  // category with more than one budget period doesn't get counted twice on the spend side.
  const dim = new Date(today0.getFullYear(), today0.getMonth() + 1, 0).getDate()
  const totalBudget = state.budgets.reduce((s, b) => s + budgetDailyRate(b) * dim, 0)
  const budgetedCategories = Array.from(new Set(state.budgets.map((b) => b.category)))
  const budgetSpent = budgetedCategories.reduce((s, category) => {
    const spent = currentMonthTx
      .filter((t) => t.type === 'expense' && t.category === category)
      .reduce((acc, t) => acc + t.amount, 0)
    return s + spent
  }, 0)
  const budgetRatio = totalBudget > 0 ? budgetSpent / totalBudget : 0
  const hasNonMonthBudgets = state.budgets.some((b) => b.period !== 'month')

  // Everything you're already committed to spending or setting aside this month — every
  // Budget (day/week/month/year budgets are all normalized to a monthly-equivalent figure
  // here, so a yearly budget still counts), plus what active Goals and Important Dates need
  // this month to stay on track. This is the number "actual money spent so far" (above)
  // doesn't capture, since most of it hasn't been logged as transactions yet.
  const plan = planForMonth(state, startOfMonth(today0))
  const savingsGoalTotal = plan.goalsTotal
  // Actual money moved into Goals/Important Dates this month (payday auto-allocation, or the
  // "add funds" quick-action — see allocateToGoal/allocateToImportantDate in App.tsx), not
  // "income minus expenses" leftover cash. Using leftover cash here used to mean that *actually
  // saving* money made this card look worse — the leftover would drop by the amount saved,
  // shrinking the ratio right when it should have grown.
  const currentMonthSaved = currentMonthTx
    .filter((t) => t.type === 'expense' && t.category === SAVINGS_CATEGORY)
    .reduce((s, t) => s + t.amount, 0)
  const savingsGoalRatio = savingsGoalTotal > 0 ? currentMonthSaved / savingsGoalTotal : 0
  const savingsGoalPercent = Math.max(0, Math.round(savingsGoalRatio * 100))

  // "In theory" projected savings: income for the selected period minus everything that
  // period is already committed to (budgets scaled the same way income is, plus goals and
  // important dates). This is what's realistically left over, not just what's left over
  // from transactions logged so far.
  const periodObligations = plan.total * monthsInPeriod
  const theoreticalSaved = income - periodObligations
  const theoreticalSavedPercent = income > 0 ? Math.round((theoreticalSaved / income) * 100) : 0

  const recent = [...state.transactions]
    .sort((a, b) => parseLocalDate(b.date).getTime() - parseLocalDate(a.date).getTime())
    .slice(0, 5)

  const topInsights = insights.slice(0, 3)

  const today = new Date()
  const dayLabel = today.toLocaleDateString(locale, { weekday: 'long', month: 'long', day: 'numeric' })

  const duePaydays = duePaydaySources(state.settings.salaryDay, state.incomeSources, state.settings.handledPaydays, today, t)
  const budgetReviews = useMemo(() => pendingBudgetPeriodReviews(state), [state])

  return (
    <div>
      {duePaydays.length > 0 && (
        <SalaryPromptBanner
          state={state}
          dueSources={duePaydays}
          onApply={applyAutoAllocations}
          onDismiss={dismissSalaryPrompt}
        />
      )}

      {budgetReviews.map((review) => (
        <BudgetPeriodBanner
          key={review.key}
          state={state}
          review={review}
          onMoveToGoal={moveBudgetSurplusToGoal}
          onMoveToImportantDate={moveBudgetSurplusToImportantDate}
          onReduceNextPeriod={reduceBudgetLimitForOverspend}
          onDismiss={dismissBudgetPeriodReview}
        />
      ))}

      <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
        <div>
          <p className="text-sm text-ink-softer mb-1">{dayLabel}</p>
          <h1 className="font-display font-semibold text-2xl sm:text-3xl text-ink">{t.dashboard.greeting}</h1>
        </div>
        <button
          onClick={() => setShowAdd(true)}
          className="inline-flex items-center gap-2 bg-ink text-paper px-4 py-2.5 rounded font-medium text-sm hover:bg-ink-light transition-colors shrink-0"
        >
          <Plus size={16} />
          {t.dashboard.addTransaction}
        </button>
      </div>

      <div className="flex justify-end mb-4 -mt-4">
        <div className="inline-flex rounded-lg border border-paper-line overflow-hidden">
          <button
            onClick={() => setPeriod('month')}
            className={`px-3.5 py-2 text-sm font-medium transition-colors ${
              period === 'month' ? 'bg-ink text-paper' : 'text-ink-softer hover:bg-paper-card'
            }`}
          >
            {t.dashboard.thisMonth}
          </button>
          <button
            onClick={() => setPeriod('year')}
            className={`px-3.5 py-2 text-sm font-medium transition-colors ${
              period === 'year' ? 'bg-ink text-paper' : 'text-ink-softer hover:bg-paper-card'
            }`}
          >
            {t.dashboard.thisYear}
          </button>
        </div>
      </div>

      {/* Stat row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-8">
        <StatCard
          label={t.dashboard.totalBalance}
          value={formatMoney(balance, state.settings.currency)}
          icon={Wallet2}
          tone="ink"
        />
        <StatCard
          label={t.dashboard.incomeFor(periodLabel)}
          value={formatMoney(income, state.settings.currency)}
          icon={TrendingUp}
          tone="sage"
        />
        <StatCard
          label={t.dashboard.spentFor(periodLabel)}
          value={formatMoney(expense, state.settings.currency)}
          icon={TrendingDown}
          tone="clay"
        />
        <StatCard
          label={t.dashboard.theoreticalSaveFor(periodLabel)}
          value={formatMoney(theoreticalSaved, state.settings.currency)}
          sub={t.dashboard.theoreticalSaveSub(theoreticalSavedPercent, periodLabel)}
          icon={PiggyBank}
          tone="gold"
        />
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Budget health + recent transactions */}
        <div className="lg:col-span-2 flex flex-col gap-6">
          <Card className="p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-display font-semibold text-base">{t.dashboard.budgetHealthTitle}</h3>
              <span className="text-sm font-tabular text-ink-softer">
                {formatMoney(budgetSpent, state.settings.currency)} / {formatMoney(totalBudget, state.settings.currency)}
              </span>
            </div>
            <ProgressBar ratio={budgetRatio} tone={budgetTone(budgetRatio)} />
            <p className="text-sm text-ink-softer mt-3">
              {state.budgets.length === 0
                ? t.dashboard.budgetHealthNoBudgets
                : budgetRatio >= 1
                ? t.dashboard.budgetHealthOver
                : budgetRatio >= 0.75
                ? t.dashboard.budgetHealthClose
                : t.dashboard.budgetHealthWithin}
              {hasNonMonthBudgets && t.dashboard.budgetHealthNonMonthNote}
            </p>
          </Card>

          <Card className="p-5">
            <div className="flex items-center justify-between mb-3">
              <h3 className="font-display font-semibold text-base">{t.dashboard.savingsGoalTitle}</h3>
              {savingsGoalTotal > 0 && (
                <span className="text-sm font-tabular text-ink-softer">
                  {formatMoney(currentMonthSaved, state.settings.currency)} / {formatMoney(savingsGoalTotal, state.settings.currency)}
                </span>
              )}
            </div>
            {savingsGoalTotal > 0 ? (
              <>
                <ProgressBar ratio={savingsGoalRatio} tone={savingsGoalRatio >= 1 ? 'sage' : savingsGoalRatio >= 0.5 ? 'gold' : 'clay'} />
                <p className="text-sm text-ink-softer mt-3">{t.dashboard.savingsGoalProgress(savingsGoalPercent)}</p>
              </>
            ) : (
              <p className="text-sm text-ink-softer">{t.dashboard.savingsGoalEmpty}</p>
            )}
          </Card>

          <Card className="p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display font-semibold text-base">{t.dashboard.recentTransactionsTitle}</h3>
              <button
                onClick={() => setView('transactions')}
                className="text-sm text-ink-softer hover:text-ink flex items-center gap-1"
              >
                {t.dashboard.viewAll} <ArrowRight size={14} />
              </button>
            </div>
            {recent.length === 0 ? (
              <EmptyState text={t.dashboard.noTransactionsYet} />
            ) : (
              <div className="flex flex-col divide-y divide-paper-line">
                {recent.map((tx) => (
                  <div key={tx.id} className="flex items-center justify-between py-3 first:pt-0 last:pb-0">
                    <div className="flex items-center gap-3 min-w-0">
                      <span className="w-8 h-8 rounded-full bg-paper flex items-center justify-center shrink-0">
                        <CategoryIconGlyph icon={iconForCategory(state.categories, tx.category)} size={14} className="text-ink-softer" />
                      </span>
                      <div className="min-w-0">
                        <p className="text-sm font-medium text-ink truncate">{tx.note || translateCategoryName(t, tx.category)}</p>
                        <p className="text-xs text-ink-softer">
                          {translateCategoryName(t, tx.category)} ·{' '}
                          {parseLocalDate(tx.date).toLocaleDateString(locale, { month: 'short', day: 'numeric' })}
                        </p>
                      </div>
                    </div>
                    <span
                      className={`font-tabular text-sm font-medium shrink-0 ml-3 ${
                        tx.type === 'income' ? 'text-sage-dark' : 'text-ink'
                      }`}
                    >
                      {tx.type === 'income' ? '+' : '-'}
                      {formatMoney(tx.amount, state.settings.currency)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>

        {/* Insights feed */}
        <div>
          <Card className="p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-display font-semibold text-base">{t.dashboard.smartInsightsTitle}</h3>
              <button
                onClick={() => setView('notifications')}
                className="text-sm text-ink-softer hover:text-ink flex items-center gap-1"
              >
                {t.dashboard.insightsAll} <ArrowRight size={14} />
              </button>
            </div>
            {topInsights.length === 0 ? (
              <EmptyState text={t.dashboard.insightsEmpty} />
            ) : (
              <div className="flex flex-col gap-3">
                {topInsights.map((insight) => (
                  <div key={insight.id} className="flex gap-2.5">
                    {insight.tone === 'positive' ? (
                      <CheckCircle2 size={16} className="text-sage-dark shrink-0 mt-0.5" strokeWidth={1.75} />
                    ) : (
                      <AlertTriangle size={16} className="text-clay-dark shrink-0 mt-0.5" strokeWidth={1.75} />
                    )}
                    <div>
                      <p className="text-sm font-medium text-ink leading-snug">{insight.title}</p>
                      <p className="text-xs text-ink-softer mt-0.5 leading-relaxed">{insight.message}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>
      </div>

      {showAdd && (
        <AddTransactionModal
          onClose={() => setShowAdd(false)}
          onSave={addTransaction}
          categories={state.categories}
          onAddCategory={addCategory}
        />
      )}
    </div>
  )
}

function StatCard({
  label,
  value,
  sub,
  icon: Icon,
  tone,
}: {
  label: string
  value: string
  sub?: string
  icon: React.ElementType
  tone: 'ink' | 'sage' | 'clay' | 'gold'
}) {
  const toneStyles: Record<string, string> = {
    ink: 'text-ink bg-ink/5',
    sage: 'text-sage-dark bg-sage-light',
    clay: 'text-clay-dark bg-clay-light',
    gold: 'text-gold-dark bg-gold-light',
  }
  return (
    <Card className="p-4">
      <div className={`inline-flex items-center justify-center w-8 h-8 rounded ${toneStyles[tone]} mb-3`}>
        <Icon size={16} strokeWidth={1.75} />
      </div>
      <p className="text-xs text-ink-softer mb-1">{label}</p>
      <p className="font-tabular font-semibold text-lg sm:text-xl text-ink truncate">{value}</p>
      {sub && <p className="text-xs text-ink-softer mt-1 leading-snug">{sub}</p>}
    </Card>
  )
}

export function EmptyState({ text }: { text: string }) {
  return (
    <div className="text-center py-8">
      <p className="text-sm text-ink-softer">{text}</p>
    </div>
  )
}
