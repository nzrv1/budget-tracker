import { CategoryIconKey, GoalIcon, ImportantDateCategory } from '../../types'
import { enDays } from './plural'

// The canonical dictionary — every other language file is typed as `Dictionary = typeof en`,
// so ru.ts/lv.ts are compiler-checked to provide the exact same keys with the exact same
// function signatures. Add a new string here first, then satisfy the type error in the other
// two files; that's what keeps all three from drifting apart.
//
// Plain strings are literal UI text. Functions take whatever dynamic values (amounts, names,
// counts, other already-translated strings) the sentence needs and return the finished string —
// deliberately whole sentences rather than glued-together fragments, so word order and grammar
// can differ per language without fighting a generic interpolation template.
const en = {
  common: {
    save: 'Save',
    cancel: 'Cancel',
    delete: 'Delete',
    edit: 'Edit',
    confirmReset: 'Confirm reset',
    income: 'income',
    expense: 'expense',
    notSet: 'Not set',
    today: 'Today',
    tomorrow: 'Tomorrow',
    // "In N days" — only ever shown for N >= 2 (Today/Tomorrow cover 0 and 1), but written to
    // hold up for any N.
    inDays: (n: number) => `In ${n} ${enDays(n)}`,
    // The auto-generated note on the expense transaction logged whenever money moves into a
    // Goal or Important Date (payday auto-allocation, or the "add funds" quick action — see
    // allocateToGoal/allocateToImportantDate in App.tsx). This becomes real, saved transaction
    // data shown later in Transactions/Dashboard, not fixed UI chrome — translated at write
    // time so it reads naturally in whatever language was active when the money was set aside.
    setAsideFor: (name: string) => `Set aside for "${name}"`,
  },

  nav: {
    dashboard: 'Dashboard',
    transactions: 'Transactions',
    reports: 'Reports',
    budgets: 'Budgets',
    goals: 'Goals',
    importantDates: 'Important Dates',
    calendar: 'Calendar',
    notifications: 'Notifications',
    settings: 'Settings',
    // Shown as a title tooltip on the logo at the top of the nav rail. This is the product's
    // own name, not a generic label — left the same in every language on purpose (see the
    // localization summary note about brand names).
    appName: 'Ledger',
  },

  periods: {
    day: 'Daily',
    week: 'Weekly',
    month: 'Monthly',
    year: 'Yearly',
    // Budgets screen: "€50 / week" style suffix after a limit.
    suffixDay: '/ day',
    suffixWeek: '/ week',
    suffixMonth: '/ month',
    suffixYear: '/ year',
    // Dashboard's "Income this month" / "Spent this year" phrasing.
    thisMonth: 'this month',
    thisYear: 'this year',
  },

  themes: {
    light: 'Light',
    dark: 'Dark',
    cyber: 'Cyber',
    red: 'Red',
    pinky: 'Pinky',
    caramel: 'Caramel',
  },

  currencies: {
    EUR: 'Euro (€)',
    USD: 'US Dollar ($)',
    GBP: 'British Pound (£)',
    PLN: 'Polish Zloty (zł)',
  },

  sidebar: {
    chooseTheme: 'Choose theme',
  },

  dashboard: {
    greeting: 'Your budget, at a glance',
    addTransaction: 'Add transaction',
    thisMonth: 'This Month',
    thisYear: 'This Year',
    totalBalance: 'Total balance',
    incomeFor: (period: string) => `Income ${period}`,
    spentFor: (period: string) => `Spent ${period}`,
    theoreticalSaveFor: (period: string) => `In theory, you can save ${period}`,
    theoreticalSaveSub: (percent: number, period: string) =>
      `${percent}% of income · after budgets, goals & important dates`,
    budgetHealthTitle: 'Monthly budget health',
    budgetHealthNoBudgets: 'No budgets set yet — set some in Budgets to track this.',
    budgetHealthOver: 'You have gone over your combined monthly budget.',
    budgetHealthClose: "You're pacing close to your monthly limit — worth watching the next few weeks.",
    budgetHealthWithin: "You're comfortably within your monthly budget.",
    budgetHealthNonMonthNote: ' Daily, weekly and yearly budgets are converted to a monthly average here.',
    savingsGoalTitle: 'Monthly savings goal',
    savingsGoalProgress: (percent: number) =>
      `${percent}% of this month's savings goal — based on what your active Goals need this month to stay on track.`,
    savingsGoalEmpty: 'No monthly savings goal right now — add a Goal with a target date to see progress here.',
    recentTransactionsTitle: 'Recent transactions',
    viewAll: 'View all',
    noTransactionsYet: 'No transactions yet — add your first one to get started.',
    smartInsightsTitle: 'Smart insights',
    insightsAll: 'All',
    insightsEmpty: 'Add a few transactions and goals — tips will show up here.',
  },

  transactions: {
    eyebrow: 'Every entry',
    title: 'Transactions',
    addButton: 'Add',
    searchPlaceholder: 'Search notes or categories...',
    allTypes: 'All types',
    income: 'Income',
    expense: 'Expense',
    allCategories: 'All categories',
    noMatch: 'No transactions match your filters.',
    editAria: 'Edit',
    deleteAria: 'Delete',
  },

  reports: {
    eyebrow: 'Where it goes',
    title: 'Reports',
    income: 'Income',
    expenses: 'Expenses',
    netSaved: 'Net saved',
    vsPrevious: (percent: string, period: string) => `${percent}% vs previous ${period}`,
    spendingByCategory: 'Spending by category',
    noExpensesThisPeriod: 'No expenses in this period yet.',
    otherCategories: 'Other categories',
    trendOverTime: 'Trend over time',
    notEnoughTrendData: 'Not enough data yet to show a trend.',
    budgetVsActual: 'Budget vs. actual',
    setBudgetsToCompare: 'Set category budgets to see this comparison.',
  },

  budgets: {
    eyebrow: 'Set your limits',
    title: 'Budgets',
    addBudgetTitle: 'Add a category budget',
    limitPlaceholder: 'Limit amount',
    addBudgetButton: 'Add budget',
    resetsLabel: 'Resets',
    errorChooseCategory: 'Choose or add a category.',
    errorEnterLimit: 'Enter a limit greater than zero.',
    errorDuplicate: (period: string) => `A ${period.toLowerCase()} budget for this category already exists.`,
    filterPlaceholder: 'Filter by category...',
    allPeriods: 'All periods',
    sortNameLabel: 'Sort: Category A–Z',
    sortUsageLabel: 'Sort: Most used first',
    sortLimitLabel: 'Sort: Highest limit first',
    noBudgetsYet: 'No budgets set yet — add one above to start tracking spending limits.',
    noMatch: 'No budgets match your filters.',
    removeAria: (category: string) => `Remove ${category} budget`,
    periodLimitLabel: (period: string) => `${period} limit`,
    ofLabel: 'of',
    overBy: (amount: string) => `Over by ${amount}`,
    closeToLimit: 'Getting close to the limit',
  },

  // The Dashboard banner shown once a budget's period (week/month/...) has just fully closed
  // out — how much of it got spent, and what to do about what's left over or gone over. See
  // lib/budgetPeriods.ts for the detection logic and BudgetPeriodBanner.tsx for the UI.
  budgetReview: {
    // Adjective form of each period, for gluing into the sentences below — kept separate from
    // periods.day/week/... (those are adverbs: "Daily", used as a toggle label) the same way
    // insights.periodWordDay/... is kept separate, since the two need different grammar and
    // that split lets Russian/Latvian pick the correct case for each without fighting a
    // one-size-fits-all interpolation.
    periodWord: { day: 'daily', week: 'weekly', month: 'monthly', year: 'yearly' },
    surplusTitle: (category: string, periodWord: string) => `${category} — ${periodWord} budget wrapped up`,
    overspentTitle: (category: string, periodWord: string) => `${category} — over ${periodWord} budget`,
    exactTitle: (category: string, periodWord: string) => `${category} — ${periodWord} budget right on target`,
    surplusMessage: (spent: string, limit: string) => `You spent ${spent} of your ${limit} budget.`,
    overspentMessage: (spent: string, limit: string) => `You spent ${spent} of your ${limit} budget.`,
    exactMessage: 'You spent exactly your budget for this period.',
    surplusAmount: (amount: string) => `${amount} left over`,
    overspentAmount: (amount: string) => `${amount} over`,
    choosePlaceholder: 'Choose where to move it...',
    goalsGroupLabel: 'Goals',
    datesGroupLabel: 'Important dates',
    moveButton: 'Move',
    // Shown instead of the move-to picker when there's a surplus but nowhere to send it yet.
    noTargets: 'Create a goal or important date to redirect leftover budget there.',
    reduceButton: (amount: string) => `Reduce next period by ${amount}`,
    skipButton: 'Skip',
    gotIt: 'Got it',
    dismissAria: 'Dismiss',
  },

  goals: {
    eyebrow: "What you're saving for",
    title: 'Goals',
    newGoalButton: 'New goal',
    emptyState: "No goals yet — create one for that flight, jacket, or trip you're saving toward.",
    targetLabel: (date: string) => `Target ${date}`,
    deleteAria: 'Delete goal',
    ofAmount: (amount: string) => `of ${amount}`,
    complete: 'Fully funded — good time to make this happen.',
    onTrack: (pace: string, days: number) => `About ${pace}/month keeps you on track for ${days} ${enDays(days)} left.`,
    passed: 'Target date has passed.',
    addFundsPlaceholder: 'Add funds',
    addFundsButton: 'Add',
    modalTitleNew: 'New goal',
    modalTitleEdit: 'Edit goal',
    nameLabel: 'Goal name',
    namePlaceholder: 'e.g. Flight to Lisbon',
    iconLabel: 'Icon',
    targetAmountLabel: 'Target amount',
    alreadySavedLabel: 'Already saved',
    targetDateLabel: 'Target date',
    errorName: 'Give your goal a name.',
    errorTarget: 'Enter a target amount greater than zero.',
    errorDate: 'Choose a target date.',
    submitCreate: 'Create goal',
  },

  importantDates: {
    eyebrow: "Don't miss these",
    title: 'Important Dates',
    newDateButton: 'New date',
    emptyState: "No important dates yet — add a birthday, holiday, or car service so you don't get caught off guard.",
    recurringSuffix: ' · yearly',
    remainingSuffix: (amount: string) => ` · ${amount} left to set aside`,
    fullyFundedSuffix: ' · fully funded',
    addFundsPlaceholder: 'Add funds',
    addFundsButton: 'Add',
    editAria: 'Edit date',
    deleteAria: 'Delete date',
    modalTitleNew: 'New important date',
    modalTitleEdit: 'Edit important date',
    nameLabel: 'Name',
    namePlaceholder: "e.g. Mom's birthday",
    categoryLabel: 'Category',
    dateLabel: 'Date',
    repeatsCheckbox: 'Repeats every year',
    amountSectionLabel: 'Amount to set aside (optional)',
    alreadySavedPlaceholder: 'Already saved',
    amountHelp: "Leave blank if this date doesn't need a savings target — just a reminder.",
    errorName: 'Give this date a name.',
    errorDate: 'Choose a date.',
    errorTarget: 'Target amount should be greater than zero.',
    submitSave: 'Save date',
    submitSaveChanges: 'Save changes',
    ofAmount: (amount: string) => `of ${amount}`,
    // Localized starting content for the one-tap quick-add presets — becomes the actual saved
    // ImportantDate.name unless the person edits it afterward, so (unlike the fixed UI chrome
    // around it) this is real seed data, translated to match the language it was created in.
    presetBirthdayLabel: 'Birthday',
    presetBirthdayName: 'Birthday',
    presetAnniversaryLabel: 'Anniversary',
    presetAnniversaryName: 'Anniversary',
    presetNewYearLabel: 'New Year',
    presetNewYearName: 'New Year',
    presetValentinesLabel: "Valentine's Day",
    presetValentinesName: "Valentine's Day",
    presetCarServiceLabel: 'Car service',
    presetCarServiceName: 'Car maintenance',
  },

  calendar: {
    eyebrow: 'Plan ahead',
    title: 'Calendar',
    monthlyToggle: 'Monthly',
    weeklyToggle: 'Weekly',
    description:
      "Money you'll want to set aside, blending your budgets with what's left to save for your goals and important dates.",
    prevYearAria: 'Previous year',
    nextYearAria: 'Next year',
    prevMonthAria: 'Previous month',
    nextMonthAria: 'Next month',
    budgetsLabel: 'Budgets',
    goalsLabel: 'Goals',
    datesLabel: 'Dates',
    budgetsAllCategoriesLabel: 'Budgets (all categories)',
    noTargetSet: 'No savings target set for this one.',
    savedLabel: (amount: string) => `${amount} saved`,
    leftLabel: (amount: string) => `${amount} left`,
    nothingPlannedThisWeek: 'Nothing planned this week.',
    monthNamesShort: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    weekdayLetters: ['M', 'T', 'W', 'T', 'F', 'S', 'S'],
  },

  notifications: {
    eyebrow: 'Nudges & tips',
    title: 'Notifications',
    emptyState: 'Nothing to flag right now — add transactions, goals, or important dates to get tailored tips here.',
    leftToSave: (amount: string) => `${amount} left to save`,
    // Appended after leftToSave() above when there's still time left, e.g.
    // "€40 left to save — about €12/week keeps you on pace for 5 days left."
    pace: (perWeek: string, days: number) => ` — about ${perWeek}/week keeps you on pace for ${days} ${enDays(days)} left.`,
    paceNone: '.',
  },

  offsets: {
    '2_months': '2 months before',
    '1_month': '1 month before',
    '2_weeks': '2 weeks before',
    '1_week': '1 week before',
    '3_days': '3 days before',
    '1_day': '1 day before',
    on_day: 'On the day',
  },

  salaryPrompt: {
    fallbackLabel: 'Payday',
    basicSalaryLabel: 'Basic salary',
    incomeSourceFallbackLabel: 'Income',
    nothingTitle: (label: string) => `${label} — nothing to set aside yet`,
    nothingMessage:
      'None of your goals or important dates need funding this month. Add a savings target to a Goal or Important Date to get suggestions here on future paydays.',
    gotIt: 'Got it',
    dismissAria: 'Dismiss',
    title: 'Payday — set money aside?',
    message: (label: string) => `${label} just landed. Here's what to set aside this month — untick anything you'd rather skip:`,
    ofSalary: (salary: string) => `of ${salary} salary ·`,
    setItAside: 'Set it aside',
    notNow: 'Not now',
  },

  addTransactionModal: {
    titleAdd: 'Add transaction',
    titleEdit: 'Edit transaction',
    amountLabel: 'Amount',
    categoryLabel: 'Category',
    dateLabel: 'Date',
    noteLabel: 'Note (optional)',
    notePlaceholder: 'What was this for?',
    errorAmount: 'Enter an amount greater than zero.',
    errorCategory: 'Choose or add a category.',
    submitAdd: 'Add transaction',
    submitSaveChanges: 'Save changes',
  },

  categorySelect: {
    placeholder: 'Choose category...',
    searchPlaceholder: 'Search or add category...',
    noMatch: 'No matching categories.',
    addAsCategory: (search: string) => `Add "${search}" as a category`,
    newFallback: 'new',
    createNameLabel: 'Category name',
    createNamePlaceholder: 'e.g. Subscriptions',
    createIconLabel: 'Icon',
    createCancel: 'Cancel',
    createConfirm: 'Create',
  },

  settings: {
    title: 'Settings',
    eyebrow: 'Your preferences',
    appearanceTitle: 'Appearance',
    themeLabel: 'Theme',
    generalTitle: 'General',
    currencyLabel: 'Currency',
    basicSalaryLabel: 'Basic salary',
    basicSalaryHelp: 'Your regular monthly income — used as a baseline for savings-rate insights.',
    paydayLabel: 'Payday',
    paydayHelp:
      "The day each month your basic salary lands. From that day, we'll suggest setting money aside for your goals and important dates automatically.",
    languageLabel: 'Language',
    languageHelp: 'Changes the language used across the whole app. Saved automatically and applied right away.',
    otherIncomeTitle: 'Other income',
    otherIncomeSubtitle: 'For a second job or freelance work that pays on a different day.',
    incomeSourceRemoveAria: (name: string) => `Remove ${name}`,
    incomeSourceDaySuffix: (day: number) => `· day ${day}`,
    addIncomeSourceLabel: 'Add income source',
    incomeNamePlaceholder: 'e.g. Freelance, Second job',
    incomeAmountPlaceholder: 'Monthly amount',
    incomePaydayPlaceholder: 'Payday',
    addIncomeSourceButton: 'Add income source',
    categoriesTitle: 'Categories',
    categoriesSubtitle: 'Used across transactions, budgets, and reports.',
    addCategoryLabel: 'Add new category',
    categoryNamePlaceholder: 'e.g. Coffee, Netflix, Gym...',
    iconLabel: 'Icon',
    iconSuggested: '(suggested)',
    addCategoryButton: 'Add category',
    notificationsTitle: 'Notifications',
    notificationsSubtitle: "Get reminded as a goal's target date or an important date gets closer.",
    notificationsEmptyHint: 'Create a goal or an important date first to set up reminders for it.',
    removeReminderAria: (name: string) => `Remove reminders for ${name}`,
    remindMeAboutLabel: 'Remind me about',
    remindGoalOption: 'A goal',
    remindDateOption: 'An important date',
    chooseGoalOption: 'Choose a goal...',
    chooseDateOption: 'Choose a date...',
    noGoalsHint: 'No goals yet — create one in the Goals tab.',
    noDatesHint: 'No important dates yet — add one in the Important Dates tab.',
    numberOfNotificationsLabel: 'Number of notifications',
    saveRemindersButton: 'Save reminders',
    dangerZoneTitle: 'Danger zone',
    dangerZoneSubtitle: "This clears all transactions, budgets, and goals stored in this browser. This can't be undone.",
    resetAllDataButton: 'Reset all data',
    cancelReset: 'Cancel',
  },

  categoryIcons: {
    food: 'Food',
    groceries: 'Groceries',
    coffee: 'Coffee',
    transport: 'Transport',
    publicTransport: 'Public transport',
    bike: 'Bike',
    fuel: 'Fuel',
    home: 'Home',
    housing: 'Housing',
    shopping: 'Shopping',
    clothing: 'Clothing',
    travel: 'Travel',
    entertainment: 'Entertainment',
    music: 'Music',
    streaming: 'Streaming',
    games: 'Games',
    bills: 'Bills',
    utilities: 'Utilities',
    water: 'Water',
    internet: 'Internet',
    phone: 'Phone',
    health: 'Health',
    medical: 'Medical',
    pharmacy: 'Pharmacy',
    fitness: 'Fitness',
    beauty: 'Beauty',
    income: 'Income',
    savings: 'Savings',
    bank: 'Bank & tax',
    creditCard: 'Credit card',
    wallet: 'Wallet',
    work: 'Work',
    education: 'Education',
    books: 'Books',
    gift: 'Gift',
    charity: 'Charity',
    tech: 'Tech',
    maintenance: 'Maintenance',
    hobby: 'Hobby',
    pets: 'Pets',
    kids: 'Kids',
    family: 'Family',
    insurance: 'Insurance',
    emergency: 'Emergency fund',
    outdoors: 'Outdoors',
    parking: 'Parking',
    other: 'Other',
  } satisfies Record<CategoryIconKey, string>,

  // Default, built-in category *names* (CategoryDef.name / Transaction.category / CategoryBudget.category).
  // These are plain data — matched by exact (case-insensitive) string everywhere, and freely
  // rename-able by the person via Settings → Categories — so unlike every other key in this file
  // they are NOT swapped for a translated string at render time by default. What IS translated is
  // only the *display* of these specific, still-English, well-known default names, via
  // lib/categoryIcons.tsx#translateCategoryName() — a small lookup that leaves any custom
  // category the person typed themselves completely alone (there's no way to "translate" text
  // nobody wrote in a known language). See the localization summary for why.
  defaultCategoryNames: {
    Food: 'Food',
    Transport: 'Transport',
    Rent: 'Rent',
    Shopping: 'Shopping',
    Travel: 'Travel',
    Entertainment: 'Entertainment',
    Bills: 'Bills',
    Health: 'Health',
    Salary: 'Salary',
    Freelance: 'Freelance',
    Savings: 'Savings',
    Other: 'Other',
  } as Record<string, string>,

  goalIcons: {
    flight: 'Flights',
    clothes: 'Clothes',
    travel: 'Travel',
    tech: 'Tech',
    home: 'Home',
    gift: 'Gift',
    car: 'Car',
    education: 'Education',
    health: 'Health',
    emergencyFund: 'Emergency fund',
    pet: 'Pet',
    hobby: 'Hobby',
    phone: 'Phone',
    music: 'Music',
    fitness: 'Fitness',
    kids: 'Kids',
    charity: 'Charity',
    business: 'Business',
    renovation: 'Renovation',
    debt: 'Debt',
    savings: 'Savings',
    insurance: 'Insurance',
    outdoors: 'Outdoors',
    wedding: 'Wedding',
    furniture: 'Furniture',
    books: 'Books',
    games: 'Games',
    food: 'Food',
    family: 'Family',
    shopping: 'Shopping',
    bike: 'Bike',
    other: 'Other',
  } satisfies Record<GoalIcon, string>,

  importantDateCategories: {
    birthday: 'Birthday',
    anniversary: 'Anniversary',
    holiday: 'Holiday',
    carMaintenance: 'Car maintenance',
    gift: 'Gift',
    medical: 'Medical',
    education: 'Education',
    travel: 'Travel',
    homeMaintenance: 'Home maintenance',
    petCare: 'Pet care',
    family: 'Family',
    finance: 'Finance',
    insurance: 'Insurance',
    subscription: 'Subscription',
    other: 'Other',
  } satisfies Record<ImportantDateCategory, string>,

  // lib/insights.ts — rule-based tips on the Dashboard/Notifications. Every entry here mirrors
  // one insight the engine can generate; kept as whole-sentence functions (see the file header
  // comment) so RU/LV can reorder clauses instead of fighting a fill-in-the-blank template.
  insights: {
    budgetExceededTitle: (category: string) => `${category} budget exceeded`,
    budgetExceededMessage: (spent: string, limit: string, periodWord: string, category: string) =>
      `You've spent ${spent} of your ${limit} ${periodWord} ${category} budget. Consider holding off on further ${category.toLowerCase()} purchases.`,
    budgetAlmostTitle: (category: string) => `${category} budget almost used up`,
    budgetAlmostMessage: (percent: number, periodWord: string, category: string) =>
      `You're at ${percent}% of your ${periodWord} ${category} budget — worth pacing the rest of your spending here.`,
    periodWordDay: 'daily',
    periodWordWeek: 'weekly',
    periodWordMonth: 'monthly',
    periodWordYear: 'yearly',
    goalReachedTitle: (goal: string) => `${goal} goal reached`,
    goalReachedMessage: (goal: string, actionWord: string) => `You've fully funded "${goal}". Good time to ${actionWord}.`,
    actionWordFlight: 'book those flight tickets',
    actionWordClothes: 'go ahead with that shopping',
    actionWordGeneric: 'go for it',
    goalAlmostTitle: (goal: string) => `${goal} — almost there`,
    goalAlmostMessage: (remaining: string, goal: string, targetDate: string) =>
      `Only ${remaining} left to reach "${goal}". At this pace you'll likely hit it before ${targetDate}.`,
    goalBehindTitle: (goal: string) => `${goal} may fall behind`,
    goalBehindMessage: (neededPerWeek: string) =>
      `You'd need to save about ${neededPerWeek}/week to hit this goal by its target date — your current pace looks slower than that.`,
    goalPassedTitle: (goal: string) => `${goal} target date passed`,
    goalPassedMessage: (goal: string, remaining: string) =>
      `The target date for "${goal}" has passed with ${remaining} still needed. Consider adjusting the date or the target amount.`,
    weeklyOverspendTitle: 'Spending faster than usual this week',
    weeklyOverspendMessage: (weekExpense: string, avgWeeklySpend: string) =>
      `This week's spending (${weekExpense}) is running well above your typical weekly pace (${avgWeeklySpend}) this month.`,
    spendingDownTitle: 'Spending trending down',
    spendingDownMessage: (percent: number) => `Projected spending this month is about ${percent}% lower than last month. Keep it up.`,
    spendingUpTitle: 'Spending trending up',
    spendingUpMessage: (percent: number) => `Projected spending this month is about ${percent}% higher than last month.`,
    onTrackTitle: 'On track this month',
    onTrackMessage: (percent: number) => `You're saving about ${percent}% of your income this month — a healthy pace toward your goals.`,
  },

  // lib/goalReminders.ts — short encouragement lines shown alongside a due reminder. Each pool
  // must keep the SAME LENGTH across en/ru/lv: a deterministic hash of the goal/date id picks an
  // index, and that index has to land on a real translated line in every language.
  reminderComments: {
    almostThere: [
      "So close — you're nearly there!",
      'The finish line is in sight, keep going.',
      "You've basically made it — just a little more.",
    ],
    goodPace: ['Great progress — keep this pace up.', "You're doing well here, nice momentum.", 'Solid progress so far — stay consistent.'],
    onTrack: ["You're on track — steady as you go.", 'Right where you need to be. Keep it steady.', 'Nice and on pace — no need to rush.'],
    needsPush: [
      'Still time to catch up — even small top-ups help.',
      "A bit behind pace, but it's very catch-uppable.",
      'Consider setting aside a little extra this week to stay on track.',
    ],
    birthday: ['Might be time to think about a gift.', "Someone's counting down to this one!", 'Worth planning something nice.'],
    carMaintenance: ["Worth booking this in before it sneaks up on you.", 'Good time to get this on the calendar.', "Don't let this one slip."],
    holiday: ['Getting closer — worth planning ahead.', 'Coming up soon on the calendar.', 'A good one to prepare for early.'],
    genericDate: ['Coming up on the calendar.', "Don't forget about this one.", 'Worth keeping an eye on.'],
    dateFunded: ['All set — already saved up for this one.', 'Fully funded — nothing more to set aside.'],
  },
}

export default en
export type Dictionary = typeof en
