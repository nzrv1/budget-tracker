import { AppState, Transaction, DEFAULT_CATEGORY_DEFS } from '../types'

function isoDaysAgo(days: number): string {
  const d = new Date()
  d.setDate(d.getDate() - days)
  return d.toISOString().slice(0, 10)
}

function isoDaysFromNow(days: number): string {
  const d = new Date()
  d.setDate(d.getDate() + days)
  return d.toISOString().slice(0, 10)
}

function tx(
  id: string,
  daysAgo: number,
  amount: number,
  type: 'income' | 'expense',
  category: string,
  note: string
): Transaction {
  return { id, date: isoDaysAgo(daysAgo), amount, type, category, note }
}

export function mockState(): AppState {
  const transactions: Transaction[] = [
    tx('t1', 27, 3200, 'income', 'Salary', 'Monthly salary'),
    tx('t2', 25, 45.5, 'expense', 'Food', 'Groceries — Rimi'),
    tx('t3', 24, 12.0, 'expense', 'Transport', 'Bus pass top-up'),
    tx('t4', 22, 850, 'expense', 'Rent', 'Monthly rent'),
    tx('t5', 20, 68.9, 'expense', 'Shopping', 'New jacket'),
    tx('t6', 18, 22.4, 'expense', 'Entertainment', 'Cinema with friends'),
    tx('t7', 17, 35.0, 'expense', 'Food', 'Groceries'),
    tx('t8', 15, 120, 'expense', 'Bills', 'Electricity + internet'),
    tx('t9', 14, 9.5, 'expense', 'Food', 'Coffee & lunch'),
    tx('t10', 12, 40, 'expense', 'Health', 'Pharmacy'),
    tx('t11', 10, 27.0, 'expense', 'Transport', 'Taxi'),
    tx('t12', 9, 60, 'expense', 'Entertainment', 'Concert ticket'),
    tx('t13', 7, 15.2, 'expense', 'Food', 'Groceries'),
    tx('t14', 6, 200, 'income', 'Freelance', 'Small design job'),
    tx('t15', 5, 33.0, 'expense', 'Shopping', 'Shoes'),
    tx('t16', 4, 18.0, 'expense', 'Food', 'Dinner out'),
    tx('t17', 3, 8.5, 'expense', 'Transport', 'Fuel top-up'),
    tx('t18', 2, 55.0, 'expense', 'Bills', 'Phone plan'),
    tx('t19', 1, 24.0, 'expense', 'Entertainment', 'Streaming subscriptions'),
    tx('t20', 0, 14.3, 'expense', 'Food', 'Groceries'),
  ]

  return {
    transactions,
    budgets: [
      { category: 'Food', limit: 300, period: 'month', createdAt: isoDaysAgo(90) },
      { category: 'Transport', limit: 100, period: 'month', createdAt: isoDaysAgo(90) },
      { category: 'Shopping', limit: 150, period: 'month', createdAt: isoDaysAgo(90) },
      { category: 'Entertainment', limit: 120, period: 'month', createdAt: isoDaysAgo(90) },
      { category: 'Bills', limit: 250, period: 'month', createdAt: isoDaysAgo(90) },
      { category: 'Health', limit: 80, period: 'month', createdAt: isoDaysAgo(90) },
    ],
    categories: DEFAULT_CATEGORY_DEFS,
    goals: [
      {
        id: 'g1',
        name: 'Flight to Lisbon',
        targetAmount: 400,
        savedAmount: 310,
        targetDate: isoDaysFromNow(35),
        icon: 'flight',
        createdAt: isoDaysAgo(60),
      },
      {
        id: 'g2',
        name: 'Winter Wardrobe Refresh',
        targetAmount: 250,
        savedAmount: 95,
        targetDate: isoDaysFromNow(70),
        icon: 'clothes',
        createdAt: isoDaysAgo(40),
      },
      {
        id: 'g3',
        name: 'Summer Trip Fund',
        targetAmount: 1200,
        savedAmount: 260,
        targetDate: isoDaysFromNow(150),
        icon: 'travel',
        createdAt: isoDaysAgo(20),
      },
    ],
    importantDates: [
      {
        id: 'id1',
        name: "Mom's birthday",
        date: isoDaysFromNow(12),
        category: 'birthday',
        recurring: true,
        createdAt: isoDaysAgo(90),
        targetAmount: 80,
        savedAmount: 35,
      },
      {
        id: 'id2',
        name: 'New Year',
        date: '2020-01-01',
        category: 'holiday',
        recurring: true,
        createdAt: isoDaysAgo(90),
      },
      {
        id: 'id3',
        name: 'Tire change',
        date: isoDaysFromNow(25),
        category: 'carMaintenance',
        recurring: false,
        createdAt: isoDaysAgo(5),
        targetAmount: 300,
        savedAmount: 120,
      },
    ],
    reminderRules: [
      { targetKind: 'goal', targetId: 'g1', offsets: ['2_months', '1_month', '2_weeks', '1_week', '3_days', '1_day'] },
      { targetKind: 'importantDate', targetId: 'id1', offsets: ['2_weeks', '3_days', '1_day'] },
      { targetKind: 'importantDate', targetId: 'id3', offsets: ['1_week', '1_day'] },
    ],
    incomeSources: [{ id: 'inc1', name: 'Freelance', amount: 600, payDay: 15 }],
    readNotificationIds: [],
    settings: {
      currency: 'EUR',
      monthlyIncome: 3200,
      theme: 'light',
      salaryDay: 1,
      language: 'en',
    },
  }
}

/**
 * A genuinely blank slate — used when the person explicitly resets their data (Settings →
 * Reset data), as opposed to mockState() above, which seeds realistic demo transactions/goals
 * for a brand new visitor who hasn't set anything up yet. Those are two different intents that
 * used to share one code path: resetData() cleared localStorage and reloaded, and loadState()
 * can't tell "first-ever visit" apart from "just wiped" — both see no saved state and fell back
 * to mockState(), so "reset" silently restored the demo dataset instead of actually emptying
 * anything. This is saved explicitly by resetData() (see App.tsx) so the reload finds real,
 * empty state instead of falling through to the mock-data branch in loadState().
 *
 * Categories are the one exception kept non-empty: they're the app's built-in taxonomy (names/
 * icons for the category picker), not user data — an empty categories list would leave nowhere
 * to file a transaction. A full reset clears records, not the app's basic scaffolding.
 */
export function emptyState(): AppState {
  return {
    transactions: [],
    budgets: [],
    categories: DEFAULT_CATEGORY_DEFS,
    goals: [],
    importantDates: [],
    reminderRules: [],
    incomeSources: [],
    readNotificationIds: [],
    settings: {
      currency: 'EUR',
      monthlyIncome: 0,
      theme: 'light',
      language: 'en',
    },
  }
}
